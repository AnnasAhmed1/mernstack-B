import React, { Children } from 'react'
import img from "../../Assets/images/place1.png"

function FixedBg({ Children, image=img,data }) {
  console.log(data[0],"fixed bggggggggggggg");
    return (
        <div className="carouselWrapper"
            style={{
                backgroundImage: `url('${data ?data[0]:image}')`,
            }}
        >
            {Children}
        </div>
    )
}

export default FixedBg