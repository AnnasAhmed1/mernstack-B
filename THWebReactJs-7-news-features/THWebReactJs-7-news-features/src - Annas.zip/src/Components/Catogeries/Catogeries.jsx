import React, { useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom';
import instance from '../../Services/Axois';

const CatogeriesFilter = ({ selected, setselected, setData, route }) => {
  const [filters, setfilters] = useState()
  const location = useLocation()
  const getCatogerisData = async () => {
    await instance.get(`/website/categories?type=${route.slice(0, -1)}`)
      .then(response => {
        setfilters(response?.data?.data?.records)
        if(location?.state){
          setselected(location?.state)
          onFilterClick(location?.state)
        }
        else {
          setselected(response?.data?.data?.records[0])
          onFilterClick(response?.data?.data?.records[0])
        }
      })
      .catch(response => {
        console.log(response, "responseresponse");
      })
  }
  useEffect(() => {
    getCatogerisData()
    if (!selected) {
      instance.get(`/website/${route}`)
        .then(response => {
          setData(response?.data?.data?.records)
        })
        .catch(response => {
          setData([])
          console.log(response, "responseresponse");
        })
    }
  }, [])

  const onFilterClick = (filter) => {
    let queryString = `categoryIds[]=${filter?.id}`
    instance.get(`/website/${route}?${queryString}`)
      .then(response => {
        setData(response?.data?.data?.records)
        setselected(filter)
        
      })
      .catch(response => {
        setData([])
        console.log(response, "responseresponse");
      })
    // setselected(prev=>[...prev,filter])
  }
  
  return (
    <div className="container">
      <div className="Catogeries-filters">
        {filters?.map((filter) => {
          return (
            <>
            <div key={filter?.id} className={`content-filter ${filter?.id == selected?.id ? 'catActive' : ''}`} onClick={() => onFilterClick(filter)}>
              <h1>{filter?.title}</h1>
            </div>
            </>
          );
        })}
      </div>
    </div>
  )
}

export default CatogeriesFilter