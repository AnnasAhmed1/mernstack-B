import React, { useState, useEffect } from "react";
import { Row, Col } from "antd";
import Layout from "../../Layout/Index";
import CatogeriesFilter from "../../Components/Catogeries/Catogeries";
import CusineSearch from "../../Components/Catogeries/CusineSearch";
import FilterButton from "../../Components/Catogeries/FlterButton";
import instance from "../../Services/Axois";
import { DownOutlined } from "@ant-design/icons";
import { Dropdown, Space } from "antd";
import SecondaryCard from "../../Components/Common/Cards/SecondaryCard";
import HunterEditor from "../../Components/Common/HunterEditor";
import PlacesHeroSlider from "../../Components/Caurosel/HeroSlider";
import SlickSliderPerks from "./SlickSliderPerks";
import SliderCardPerks from "./SliderCardPerks";
import "./perks.scss";

export default function Perks() {
  const [data, setData] = useState([
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
  ]);
  const [data2, setData2] = useState([
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
  ]);
  const [data3, setData3] = useState([
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
  ]);

  const [loading, setloading] = useState(true);
  const [additonalData, setadditonalData] = useState([]);
  const [coffeCardData, setcoffeCardData] = useState([]);
  const [popularData, setpopularData] = useState([]);
  const getAdditinalData = () => {
    instance
      .get("/website/places?perkTitle=1&sort=latest")
      .then((response) => {
        setadditonalData(response?.data?.data?.records);
        getCoffeCardData();
      })
      .catch((response) => {
        console.log(response, "responseresponse");
      });
  };
  const getCoffeCardData = () => {
    instance
      .get("/website/places?coffeeCard=1")
      .then((response) => {
        setcoffeCardData(response?.data?.data?.records);
        getPopularCardData();
      })
      .catch((response) => {
        console.log(response, "responseresponse");
      });
  };
  const getPopularCardData = () => {
    instance
      .get("/website/guides?perkTitle=1&sort=latest")
      .then((response) => {
        setpopularData(response?.data?.data?.records);
        setloading(false);
      })
      .catch((response) => {
        console.log(response, "responseresponse");
      });
  };
  useEffect(() => {
    getAdditinalData();
  }, []);

  return (
    <main className="perks-main-container">
      <h1>POPULAR PERKS</h1>
      <div className="hero-sliderPerks">
        <SlickSliderPerks>
          {popularData?.map((card, index) => {
            return <SliderCardPerks key={index} data={card} />;
          })}
        </SlickSliderPerks>
      </div>
      <h1>NEW ADDITIONS</h1>
      <section className="perks-addition-container">
        {additonalData?.map((card, index) => {
          return <SliderCardPerks height={"auto"} key={index} data={card} />;
        })}
      </section>
      <h1>THE HUNTR COFFEE CARD PARTNERS</h1>
      <div className="hero-sliderPerks">
        <SlickSliderPerks>
          {coffeCardData?.map((card, index) => {
            return <SliderCardPerks key={index} data={card} icon={true} />;
          })}
        </SlickSliderPerks>
      </div>
    </main>
  );
}
