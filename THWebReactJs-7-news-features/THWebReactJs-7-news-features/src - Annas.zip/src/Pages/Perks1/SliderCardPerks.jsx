import React from "react";
import { CoffeeOutlined } from "@ant-design/icons";
import "./perks.scss";

const SliderCardPerks = ({ data, icon }) => {
  return (
    <div className="perk-card slick .slick-center slick-list">
      <img
        style={{
          width: "100%",
          height: "60%",
        }}
        src={require("../../Assets/images/perk_cark_img.png")}
      />
      <div>
        <p>{data.p1}</p>
        <p>
          {data.p2}
          {icon ? <CoffeeOutlined /> : null}
        </p>
        {data.p3 ? <p>{data.p3}</p> : null}
      </div>
    </div>
  );
};

export default SliderCardPerks;
