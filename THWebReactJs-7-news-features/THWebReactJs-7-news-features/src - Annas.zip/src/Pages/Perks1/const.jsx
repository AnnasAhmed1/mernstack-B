// 3
const addData = [
  {
    id: 5,
    title: "10 Supper Clubs to check out in Dubai",
    slug: "10-supper-clubs-to-check-out-in-dubai",
    categoryTitle: "Food & Drink",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/guides/5/feature/74566.jpg",
    description:
      "Did someone say dinner at a strangers house?\n\nVery much a thing in other cities around the world, su...",
    placesCount: 5,
  },
  {
    id: 2,
    title: "The Ultimate Road Trip Guide: 12 Ways to Esca\u2026",
    slug: "the-ultimate-road-trip-guide-12-ways-to-esca",
    categoryTitle: "Perks ",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/guides/2/feature/32330.png",
    description: "Guide detail",
    placesCount: 1,
  },
  {
    id: 1,
    title: "The places we can\u2019t stop thinking about right now\u2026",
    slug: "the-places-we-cant-stop-thinking-about-right-now",
    categoryTitle: "Cafes",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/guides/1/feature/87438.png",
    description:
      "Dubai and the UAE is filled with wonderful places. We are not short of fantastic restaurants, cafes,...",
    placesCount: 1,
  },
];

// 2
const coffeeData = [
  {
    id: 1,
    title: "SAN Beach: A little slice of heaven on the Palm Jumeirah",
    slug: "san-beach-a-little-slice-of-heaven-on-the-palm-jumeirah",
    excerpt:
      "Head here for breakfast, lunch, dinner, drinks and everything in between, or park up on a lounger and spend the day with\u2026",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/places/1/slider/8829.jpg",
    distance: "1,185.99km",
    cardUsps: ["VIEWS", "OUTSIDE SEATING", "BUZZY ATMOSPHERE"],
    cardCategory: "RESTAURANTS & LICENSED BAR IN DUBAI",
    coffeeCard: true,
    perk: true,
    perkObj: {
      id: 1,
      title: "20% off the total bill",
      description: null,
    },
    location: {
      lon: 55.27436332098571,
      lat: 25.19720199948545,
    },
    categories: [
      {
        id: 2,
        title: "Restaurants",
        slug: "restaurants-place",
        markerIconUrl: null,
      },
      {
        id: 6,
        title: "Licensed Bar",
        slug: "licensed-bar-place",
        markerIconUrl: null,
      },
    ],
  },
  {
    id: 7,
    title: "Ritaj: A Hyderabadi biryani gem in the TCA",
    slug: "ritaj-a-hyderabadi-biryani-gem-in-the-tca",
    excerpt: "A casual spot with super reasonable prices",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/places/7/slider/77721.jpg",
    distance: "1,279.44km",
    cardUsps: ["ALCOHOL-FREE", "HOMEGROWN", "CASUAL DINING SPOT"],
    cardCategory: "RESTAURANTS IN ABU DHABI",
    coffeeCard: true,
    perk: true,
    perkObj: { id: 1, title: "20% off the total bill", description: null },
    location: { lon: 54.37907975452468, lat: 24.50390867803122 },
    categories: [
      {
        id: 2,
        title: "Restaurants",
        slug: "restaurants-place",
        markerIconUrl: null,
      },
    ],
  },
];

// 3
const popData = [
  {
    id: 5,
    title: "10 Supper Clubs to check out in Dubai",
    slug: "10-supper-clubs-to-check-out-in-dubai",
    categoryTitle: "Food & Drink",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/guides/5/feature/74566.jpg",
    description:
      "Did someone say dinner at a strangers house?\n\nVery much a thing in other cities around the world, su...",
    placesCount: 5,
  },
  {
    id: 2,
    title: "The Ultimate Road Trip Guide: 12 Ways to Esca\u2026",
    slug: "the-ultimate-road-trip-guide-12-ways-to-esca",
    categoryTitle: "Perks ",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/guides/2/feature/32330.png",
    description: "Guide detail",
    placesCount: 1,
  },
  {
    id: 1,
    title: "The places we can\u2019t stop thinking about right now\u2026",
    slug: "the-places-we-cant-stop-thinking-about-right-now",
    categoryTitle: "Cafes",
    featureImageUrl:
      "https://backend.swipetechstudio.com/storage/guides/1/feature/87438.png",
    description:
      "Dubai and the UAE is filled with wonderful places. We are not short of fantastic restaurants, cafes,...",
    placesCount: 1,
  },
];
