import React, { useState, useEffect } from "react";
import { Row, Col } from "antd";
import Layout from "../../Layout/Index";
import CatogeriesFilter from "../../Components/Catogeries/Catogeries";
import CusineSearch from "../../Components/Catogeries/CusineSearch";
import FilterButton from "../../Components/Catogeries/FlterButton";
import instance from "../../Services/Axois";
import { DownOutlined } from "@ant-design/icons";
import { Dropdown, Space } from "antd";
import SecondaryCard from "../../Components/Common/Cards/SecondaryCard";
import HunterEditor from "../../Components/Common/HunterEditor";
import PlacesHeroSlider from "../../Components/Caurosel/HeroSlider";
import SlickSliderPerks from "./SlickSliderPerks";
import SliderCardPerks from "./SliderCardPerks";
import "./perks.scss";

export default function Perks1() {
  const [data, setData] = useState([
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
    {
      p1: "Buy 1 Get 1 Free deals",
      p2: "At KOYO, Cafe No 57, Haus & more…",
      p3: "26 PLACES",
    },
  ]);
  const [data2, setData2] = useState([
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Buy 1 Get 1 Free Day Passes at Caesars Palace",
      p2: "CAFE IN DUBAI",
    },
  ]);
  const [data3, setData3] = useState([
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
    {
      p1: "Coffee Shop Title",

      p2: "CAFE IN DUBAI",
    },
  ]);

  const addData = [
    {
      id: 5,
      title: "10 Supper Clubs to check out in Dubai",
      slug: "10-supper-clubs-to-check-out-in-dubai",
      categoryTitle: "Food & Drink",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/guides/5/feature/74566.jpg",
      description:
        "Did someone say dinner at a strangers house?\n\nVery much a thing in other cities around the world, su...",
      placesCount: 5,
    },
    {
      id: 2,
      title: "The Ultimate Road Trip Guide: 12 Ways to Esca\u2026",
      slug: "the-ultimate-road-trip-guide-12-ways-to-esca",
      categoryTitle: "Perks ",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/guides/2/feature/32330.png",
      description: "Guide detail",
      placesCount: 1,
    },
    {
      id: 1,
      title: "The places we can\u2019t stop thinking about right now\u2026",
      slug: "the-places-we-cant-stop-thinking-about-right-now",
      categoryTitle: "Cafes",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/guides/1/feature/87438.png",
      description:
        "Dubai and the UAE is filled with wonderful places. We are not short of fantastic restaurants, cafes,...",
      placesCount: 1,
    },
  ];

  const coffeeData = [
    {
      id: 1,
      title: "SAN Beach: A little slice of heaven on the Palm Jumeirah",
      slug: "san-beach-a-little-slice-of-heaven-on-the-palm-jumeirah",
      excerpt:
        "Head here for breakfast, lunch, dinner, drinks and everything in between, or park up on a lounger and spend the day with\u2026",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/places/1/slider/8829.jpg",
      distance: "1,185.99km",
      cardUsps: ["VIEWS", "OUTSIDE SEATING", "BUZZY ATMOSPHERE"],
      cardCategory: "RESTAURANTS & LICENSED BAR IN DUBAI",
      coffeeCard: true,
      perk: true,
      perkObj: {
        id: 1,
        title: "20% off the total bill",
        description: null,
      },
      location: {
        lon: 55.27436332098571,
        lat: 25.19720199948545,
      },
      categories: [
        {
          id: 2,
          title: "Restaurants",
          slug: "restaurants-place",
          markerIconUrl: null,
        },
        {
          id: 6,
          title: "Licensed Bar",
          slug: "licensed-bar-place",
          markerIconUrl: null,
        },
      ],
    },
    {
      id: 7,
      title: "Ritaj: A Hyderabadi biryani gem in the TCA",
      slug: "ritaj-a-hyderabadi-biryani-gem-in-the-tca",
      excerpt: "A casual spot with super reasonable prices",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/places/7/slider/77721.jpg",
      distance: "1,279.44km",
      cardUsps: ["ALCOHOL-FREE", "HOMEGROWN", "CASUAL DINING SPOT"],
      cardCategory: "RESTAURANTS IN ABU DHABI",
      coffeeCard: true,
      perk: true,
      perkObj: { id: 1, title: "20% off the total bill", description: null },
      location: { lon: 54.37907975452468, lat: 24.50390867803122 },
      categories: [
        {
          id: 2,
          title: "Restaurants",
          slug: "restaurants-place",
          markerIconUrl: null,
        },
      ],
    },
  ];

  const popData = [
    {
      id: 5,
      title: "10 Supper Clubs to check out in Dubai",
      slug: "10-supper-clubs-to-check-out-in-dubai",
      categoryTitle: "Food & Drink",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/guides/5/feature/74566.jpg",
      description:
        "Did someone say dinner at a strangers house?\n\nVery much a thing in other cities around the world, su...",
      placesCount: 5,
    },
    {
      id: 2,
      title: "The Ultimate Road Trip Guide: 12 Ways to Esca\u2026",
      slug: "the-ultimate-road-trip-guide-12-ways-to-esca",
      categoryTitle: "Perks ",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/guides/2/feature/32330.png",
      description: "Guide detail",
      placesCount: 1,
    },
    {
      id: 1,
      title: "The places we can\u2019t stop thinking about right now\u2026",
      slug: "the-places-we-cant-stop-thinking-about-right-now",
      categoryTitle: "Cafes",
      featureImageUrl:
        "https://backend.swipetechstudio.com/storage/guides/1/feature/87438.png",
      description:
        "Dubai and the UAE is filled with wonderful places. We are not short of fantastic restaurants, cafes,...",
      placesCount: 1,
    },
  ];

  const [loading, setloading] = useState(true);
  const [additonalData, setadditonalData] = useState([]);
  const [coffeCardData, setcoffeCardData] = useState([]);
  const [popularData, setpopularData] = useState([]);
  const getAdditinalData = () => {
    instance
      .get("/website/places?perkTitle=1&sort=latest")
      .then((response) => {
        setadditonalData(response?.data?.data?.records);
        getCoffeCardData();
      })
      .catch((response) => {
        console.log(response, "responseresponse");
      });
  };
  const getCoffeCardData = () => {
    instance
      .get("/website/places?coffeeCard=1")
      .then((response) => {
        setcoffeCardData(response?.data?.data?.records);
        getPopularCardData();
      })
      .catch((response) => {
        console.log(response, "responseresponse");
      });
  };
  const getPopularCardData = () => {
    instance
      .get("/website/guides?perkTitle=1&sort=latest")
      .then((response) => {
        setpopularData(response?.data?.data?.records);

        setloading(false);
      })
      .catch((response) => {
        console.log(response, "responseresponse");
      });
  };
  useEffect(() => {
    getAdditinalData();
  }, []);

  return (
    <main className="perks-main-container">
      <h1>POPULAR PERKS</h1>
      <div className="hero-sliderPerks">
        <SlickSliderPerks>
          {popData?.map((card, index) => {
            return <SliderCardPerks key={index} data={card} />;
          })}
        </SlickSliderPerks>
      </div>
      <h1>NEW ADDITIONS</h1>
      <section className="perks-addition-container">
        {addData?.map((card, index) => {
          return <SliderCardPerks key={index} data={card} />;
        })}
      </section>
      <h1>THE HUNTR COFFEE CARD PARTNERS</h1>
      <div className="hero-sliderPerks">
        <SlickSliderPerks>
          {coffeeData?.map((card, index) => {
            return <SliderCardPerks key={index} data={card} icon={true} />;
          })}
        </SlickSliderPerks>
      </div>
    </main>
  );
}
