import "./features.scss";

const FeaturesList = ({ listData }) => {
  console.log(listData);
  return (
    <div className="features-list-container">
      {listData?.map((v, i) => {
        return (
          <div>
            <p>{v}</p>
            <input
              type="checkbox"
              id="demoCheckbox"
              name="checkbox"
              value="1"
            />
          </div>
        );
      })}
    </div>
  );
};

export default FeaturesList;
