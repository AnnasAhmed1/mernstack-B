import React, { useState } from "react";
import "./features.scss";
import FeatureLabel from "./feature_label.jsx";
import FeaturesList from "./feature_list";
const Features = () => {
  const [labels, setLabels] = useState([
    { value: "genre", active: true },
    { value: "emirate", active: false },
    { value: "neighbourhood", active: false },
    { value: "usps", active: false },
    { value: "cuisines", active: false },
  ]);

  const items = [
    [
      "genre data",
      "genre data",
      "genre data",
      "genre data",
      "genre data",
      "genre data",
      "genre data",
      "genre data",
    ],
    [
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
      "emirate data",
    ],
    [
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
      "neighbourhood data",
    ],
    [
      "usps data",
      "usps data",
      "usps data",
      "usps data",
      "usps data",
      "usps data",
      "usps data",
      "usps data",
      "usps data",
    ],
    [
      "cuisines data",
      "cuisines data",
      "cuisines data",
      "cuisines data",
      "cuisines data",
      "cuisines data",
      "cuisines data",
      "cuisines data",
      "cuisines data",
      "cuisines data",
    ],
  ];

  const toggleFunc = (index) => {
    labels.map((v, i) => {
      labels[i].active = false;
    });
    labels[index].active = true;
    setLabels([...labels]);
  };

  return (
    <>
      <main className="features-main">
        <h1>Filters</h1>
        <section>
          <FeatureLabel
            labelsData={labels}
            listData={items}
            toggleFunc={toggleFunc}
          />
        </section>
      </main>
      <br />
      <br />
      <br />
      <br />
      <br />
    </>
  );
};

export default Features;
