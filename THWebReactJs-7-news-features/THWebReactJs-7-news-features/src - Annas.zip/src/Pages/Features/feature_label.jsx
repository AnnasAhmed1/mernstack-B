import { act } from "@testing-library/react";
import { useState } from "react";
import "./features.scss";
import FeaturesList from "./feature_list";

const FeaturesLabel = ({ labelsData, listData, toggleFunc }) => {
  const [activeIndex, setActiveIndex] = useState(0);
  return (
    <>
      <div className="features-label-container">
        {labelsData?.map((v, i) => {
          return (
            <p
              key={i}
              className={v.active ? "active-label" : ""}
              onClick={() => {
                toggleFunc(i);
                setActiveIndex(i);
              }}
            >
              {v.value}
            </p>
          );
        })}
      </div>
      <FeaturesList listData={listData ? listData[activeIndex] : "null"} />
    </>
  );
};

export default FeaturesLabel;
