import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom';
import FixedBg from '../../Components/Caurosel/FixedBg';
import instance from '../../Constant';
import Layout from "../../Layout/Index";

function PlaceDetails() {
    let { id } = useParams();
    useEffect(() => {
        instance.get(`/website/places/${id}`)
            .then(response => {
                console.log(response?.data)
            })
            .catch(response => {
                console.log(response, "responseresponse");
            })
    },
        [])
        return (
            <Layout>
              {/* Caurosel starts */}
              {/* <PlacesDetailCaurosel /> */}
              <FixedBg>

                <h1>as</h1>
              </FixedBg>
              {/* Caurosel ends */}
        
            </Layout>
          );
}

export default PlaceDetails