import "./App.scss";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home/Index";
import NewsFeatures from "./Pages/NewsFeatures/Index";
import Places from "./Pages/Places/Index";
import Guides from "./Pages/Guides/Index";
import PlaceDetails from "./Pages/Places/PlaceDetails";
import NewsFeaturesDetails from "./Pages/NewsFeatures/Details";
import Perks from "./Pages/Perks/Index";
import EnquiriesBottomComp from "./Pages/EnquiriesBottomComp/Index";
import Features from "./Pages/Features/Index";
import Partners from "./Pages/Partners/Index";
import Perks1 from "./Pages/Perks1/Index";
import PolicyComp from "./Pages/Policy_Comp/policy_comp";

function App() {
  return (
    <Router>
      <Routes>
        {/* Default/Home */}
        <Route path="/" element={<Home />} />
        {/* News & Features */}
        <Route path="/news-features" element={<NewsFeatures />} />
        <Route path="/news-features/:id" element={<NewsFeaturesDetails />} />

        <Route path="/places" element={<Places />} />
        {/* <Route path="/places/:placeName" element={<Places />} /> */}
        <Route path="/placeDetails/:id" element={<PlaceDetails />} />
        <Route path="/guides" element={<Guides />} />
        <Route path="/perks" element={<Perks />} />
        <Route path="/perks1" element={<Perks1 />} />
        <Route path="/EnquiriesBottomComp" element={<EnquiriesBottomComp />} />
        <Route path="/features" element={<Features />} />
        <Route path="/partners" element={<Partners />} />
        <Route path="/policyComp" element={<PolicyComp />} />
        {/* <Route path="/guides/:guideName" element={<Guides />} /> */}
      </Routes>
    </Router>
  );
}

export default App;
