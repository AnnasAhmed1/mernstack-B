import React, { useState } from "react";
import "./features.scss";
import FeatureLabel from "./feature_label.jsx";
const FilterModelPlaces = ({labels,items}) => {
  const [activeIndex, setActiveIndex] = useState(0);


  // const items = [
  //   [
  //     "genre data",
  //     "genre data",
  //     "genre data",
  //     "genre data",
  //     "genre data",
  //     "genre data",
  //     "genre data",
  //     "genre data",
  //   ],
  //   [
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //     "emirate data",
  //   ],
  //   [
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //     "neighbourhood data",
  //   ],
  //   [
  //     "usps data",
  //     "usps data",
  //     "usps data",
  //     "usps data",
  //     "usps data",
  //     "usps data",
  //     "usps data",
  //     "usps data",
  //     "usps data",
  //   ],
  //   [
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //     "cuisines data",
  //   ],
  // ];

  const toggleFunc = (FilterModelPlaces) => {
    setActiveIndex(FilterModelPlaces)

  };

  return (
      <div className="features-main">
        {/* <h1>Filters</h1> */}
        <div className="wrapperFeaturePlaces">
          <FeatureLabel
            labelsData={labels}
            listData={items}
            toggleFunc={toggleFunc}
            activeIndex={activeIndex}
            setActiveIndex={setActiveIndex}
          />
        </div>
      </div>
  );
};

export default FilterModelPlaces;
