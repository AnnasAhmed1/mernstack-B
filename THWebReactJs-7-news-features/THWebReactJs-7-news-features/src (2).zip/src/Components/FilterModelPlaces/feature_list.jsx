import "./features.scss";

const FeaturesList = ({ listData }) => {
  console.log(listData);
  return (
    <div className="features-list-container">
      {listData?.map((v, i) => {
        return (
          <div key={i}>
            <p style={{color:v?.comingSoon ? 'grey':''}}>{v?.title}</p>
            <input
              type="checkbox"
              id="demoCheckbox"
              name="checkbox"
              value="1"
              disabled={v?.comingSoon ? true:false}
            />
          </div>
        );
      })}
    </div>
  );
};

export default FeaturesList;
