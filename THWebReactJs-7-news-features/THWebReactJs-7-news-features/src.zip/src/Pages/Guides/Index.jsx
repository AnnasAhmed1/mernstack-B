import React, { useState, useEffect } from "react";
import { Row, Col } from "antd";
import Layout from "../../Layout/Index";
import CatogeriesFilter from "../../Components/Catogeries/Catogeries";
import CusineSearch from "../../Components/Catogeries/CusineSearch";
import FilterButton from "../../Components/Catogeries/FlterButton";
import instance from "../../Services/Axois";
import { DownOutlined } from "@ant-design/icons";
import { Dropdown, Space } from "antd";
import HunterEditor from "../../Components/Common/HunterEditor";
import GuidesHeroSlider from "../../Components/Caurosel/HeroSlider";
import PrimaryCard from "../../Components/Common/Cards/PrimaryCard";

export default function Index() {
  // states
  const [guidesCard, setguidesCard] = useState([]);
  const [TrendingCar, setTrendingCar] = useState([]);
  const [selectedCusine, setselectedCusine] = useState(1);
  const [selected, setselected] = useState();

  const items = [
    {
      label: <a href="https://www.antgroup.com">1st menu item</a>,
      key: "0",
    },
    {
      label: <a href="https://www.aliyun.com">2nd menu item</a>,
      key: "1",
    },
    {
      type: "divider",
    },
    {
      label: "3rd menu item",
      key: "3",
    },
  ];

  useEffect(() => {
    instance
      .get("/website/guides?trending=1")
      .then((response) => {
        setTrendingCar(response?.data?.data?.records);
      })
      .catch((response) => {
        console.log(response, "responseresponse");
      });
  }, []);

  return (
    <Layout>
      {/* Caurosel starts */}
      <GuidesHeroSlider
        pageTitle="Guides"
        data={TrendingCar}
        routeTitle="guides"
      />
      {/* Caurosel ends */}

      <div className="filterHeader">
        <FilterButton />
        <div className="filterByUae">
          <h2>Filter by Emirates</h2>
          <Dropdown
            menu={{
              items,
            }}
            trigger={["click"]}
          >
            <a onClick={(e) => e.preventDefault()} className="filterByEmr">
              <Space>
                0XB
                <DownOutlined />
              </Space>
            </a>
          </Dropdown>
        </div>
      </div>
      {/* Filters starts */}
      <CatogeriesFilter
        selected={selected}
        setselected={setselected}
        setData={setguidesCard}
        route={"guides"}
      />
      <CusineSearch selected={selectedCusine} setselected={setselectedCusine} />
      {/* Filters ends */}

      {/* guides Section Starts */}
      <section className="card-section-wrapper">
        <div className="container">
          <div className="card-section-title">
            <h2>{selected?.title}</h2>
            {/* <Link to="/guides">
              View More <ArrowRightOutlined />
            </Link> */}
          </div>

          <div className="card-section-content">
            <Row gutter={[24, 24]}>
              {guidesCard?.map((card) => {
                return (
                  <Col xs={24} sm={8} key={card?.key}>
                    <PrimaryCard data={card} />
                  </Col>
                );
              })}
            </Row>
          </div>
        </div>
      </section>
      {/* guides Section Ends */}

      {/* Huntr Editor's Starts */}
      <HunterEditor />
      {/* Huntr Editor's Ends */}
    </Layout>
  );
}
