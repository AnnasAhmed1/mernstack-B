import React, { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import FixedBg from "../../Components/Caurosel/FixedBg";
import instance from "../../Services/Axois";
import Layout from "../../Layout/Index";
import Usps from "../../Components/Places/Usps";
import "../../Styles/Pages/_placesDetails.scss";
import HeroSlickSlider from "../../Components/Home/HeroSlickSlider";
import Place1Image from "../../Assets/images/db1.jpg";
import Place2Image from "../../Assets/images/db2.jpg";
import Place3Image from "../../Assets/images/db3.jpg";
import { EnvironmentOutlined } from "@ant-design/icons";
import HeroSliderCardPlaces from "../../Components/Places/HeroSliderCardPlaces";
import BottomBarDetail from "../../Components/Places/BottomBarDetail";
import parse from "html-react-parser";
import DetailsHeader from "../../Components/Common/DetailsHeader";
import HeroSlickSliderPlaces from "../../Components/Places/HeroSlickSliderPlaces";
function PlaceDetails() {
  const location = useLocation();
  const [PreviousData, setPreviousData] = useState(location?.state);
  console.log(PreviousData, "PreviousDataPreviousData");
  let { id } = useParams();
  const [detailData, setdetailData] = useState({});
  const heroSliderImage = [Place1Image, Place2Image, Place3Image];
  useEffect(() => {
    instance
      .get(`/website/places/${id}`)
      .then((response) => {
        setdetailData(response?.data?.data);
        console.log(response?.data?.data, "responsee");
      })
      .catch((response) => {
        console.log(response, "errorrr");
      });
  }, []);

  const data = detailData?.description.split("</p>");
  console.log(data);

  return (
    <Layout>
      {detailData && Object.keys(detailData)?.length > 0 ? (
        <>
          <FixedBg data={detailData?.sliderImages}>
            <h1>as</h1>
          </FixedBg>
          <main className="place-details-container">
            <DetailsHeader
              categories={["Places", PreviousData?.cardCategory]}
            />
            <h1>
              {detailData?.title ||
                "Lucia's: An upscale Italian affair in Downtown"}
            </h1>
            <p>
              <EnvironmentOutlined />
              {detailData?.address || " 45 Burj Khalifa Street, Dubai"}
            </p>
            <Usps data={detailData?.usps} />
            <hr />
            <div className="CapitalLetterWrapper">
              {/* <span>
                {
                  detailData?.description[3] || 'D'
                }
                </span> */}
              {parse(data[0].charAt(3))}
              <p>{parse(data[0].slice(4, -1))}</p>
              {/* <p>
                  {detailData?.description || "  ubai and the UAE is filled with wonderful places. We are not short of fantastic restaurants, cafes, and new gems arepopping up, daily. But sometimes we visit a place and we leave, and we just can't stop thinking about it. Whether it was the vibes, the food, the views, or (more often than not) a combination of all three, here are the  places that The HUNTR can't stop thinking right now…"}
                </p> */}
            </div>
            <p>{parse(data[1] + "</p>")}</p>
            {/* <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus
                nemo, non officia iste, reiciendis minima vero aliquam architecto
                dolorum nulla necessitatibus et cumque veniam sed? Iusto rerum vero
                pariatur minima. Lorem ipsum dolor sit amet consectetur adipisicing
                elit. Reiciendis provident similique placeat. Maiores iure assumenda
                eligendi quasi, reiciendis in dolor sit amet fugiat eos, consequatur
                asperiores voluptas veniam nam deserunt cumque at. Deserunt?
              </p> */}
            <br />
            <div className="hero-slider">
              {/* <div className="slider-title"></div> */}
              <HeroSlickSliderPlaces>
                {detailData?.articles[0]?.images?.map((card) => {
                  return <HeroSliderCardPlaces key={card?.key} data={card} />;
                })}
              </HeroSlickSliderPlaces>
            </div>
            <br />
            <br />
            <p>
              {parse(detailData?.articles[0]?.text) ||
                "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus nemo, non officia iste, reiciendis minima vero aliquam architecto dolorum nulla necessitatibus et cumque veniam sed? Iusto rerum vero pariatur minima. Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis provident similique placeat. Maiores iure assumenda eligendi quasi, reiciendis in fugiat eos consequatur asperiores voluptas veniam nam deserunt cumque at. Deserunt?"}
            </p>
            <hr />
            <BottomBarDetail data={detailData?.editor} />
          </main>
        </>
      ) : (
        <h1>Loading...</h1>
      )}
    </Layout>
  );
}

export default PlaceDetails;
