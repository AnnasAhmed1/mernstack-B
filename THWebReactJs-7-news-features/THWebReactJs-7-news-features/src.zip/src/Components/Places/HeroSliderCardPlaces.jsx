import React from "react";

const HeroSliderCardPlaces = ({ data = {} }) => {
  return (
    <div>
      <img
        style={{
          width: "100%",
        }}
        src={data}
        alt="places slider"
      />
    </div>
  );
};

export default HeroSliderCardPlaces;
