import "./App.scss";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home/Index";
import NewsFeatures from "./Pages/NewsFeatures/Index";
import Places from "./Pages/Places/Index";
import Guides from "./Pages/Guides/Index";
import PlaceDetails from "./Pages/Places/PlaceDetails";
import NewsFeaturesDetails from "./Pages/NewsFeatures/Details";

function App() {
  return (
    <Router>
      <Routes>
        {/* Default/Home */}
        <Route path="/" element={<Home />} />
        {/* News & Features */}
        <Route path="/news-features" element={<NewsFeatures />} />
        <Route path="/news-features/:id" element={<NewsFeaturesDetails />} />

        <Route path="/places" element={<Places />} />
        {/* <Route path="/places/:placeName" element={<Places />} /> */}
        <Route path="/placeDetails/:id" element={<PlaceDetails />} />
        <Route path="/guides" element={<Guides />} />
        {/* <Route path="/guides/:guideName" element={<Guides />} /> */}
      </Routes>
    </Router>
  );
}

export default App;
